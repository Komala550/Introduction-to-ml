Place the data files in the folder where python notebooks are in.
Open the python Notebook and run